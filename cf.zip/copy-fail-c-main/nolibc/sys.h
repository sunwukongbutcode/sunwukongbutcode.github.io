/* SPDX-License-Identifier: LGPL-2.1 OR MIT */
/*
 * Syscall definitions for NOLIBC (those in man(2))
 * Copyright (C) 2017-2021 Willy Tarreau <w@1wt.eu>
 */

/* make sure to include all global symbols */
#include "nolibc.h"

#ifndef _NOLIBC_SYS_H
#define _NOLIBC_SYS_H

#include "std.h"

/* system includes */
#include <linux/unistd.h>
#include <linux/signal.h>  /* for SIGCHLD */
#include <linux/termios.h>
#include <linux/mman.h>
#include <linux/fs.h>
#include <linux/loop.h>
#include <linux/time.h>
#include <linux/auxvec.h>
#include <linux/fcntl.h> /* for O_* and AT_* */
#include <linux/sched.h> /* for CLONE_* */
#include <linux/stat.h>  /* for statx() */

#include "errno.h"
#include "stdarg.h"
#include "types.h"


/* Syscall return helper: takes the syscall value in argument and checks for an
 * error in it. This may only be used with signed returns (int or long), but
 * not with pointers. An error is any value < 0. When an error is encountered,
 * -ret is set into errno and -1 is returned. Otherwise the returned value is
 * passed as-is with its type preserved.
 */

#define __sysret(arg)							\
({									\
	__typeof__(arg) __sysret_arg = (arg);				\
	(__sysret_arg < 0)                              /* error ? */	\
		? (({ SET_ERRNO(-__sysret_arg); }), -1) /* ret -1 with errno = -arg */ \
		: __sysret_arg;                         /* return original value */ \
})

/* Syscall ENOSYS helper: Avoids unused-parameter warnings and provides a
 * debugging hook.
 */

static __inline__ int __nolibc_enosys(const char *syscall, ...)
{
	(void)syscall;
	return -ENOSYS;
}


/* Functions in this file only describe syscalls. They're declared static so
 * that the compiler usually decides to inline them while still being allowed
 * to pass a pointer to one of their instances. Each syscall exists in two
 * versions:
 *   - the "internal" ones, which matches the raw syscall interface at the
 *     kernel level, which may sometimes slightly differ from the documented
 *     libc-level ones. For example most of them return either a valid value
 *     or -errno. All of these are prefixed with "_sys_". They may be called
 *     by non-portable applications if desired.
 *
 *   - the "exported" ones, whose interface must closely match the one
 *     documented in man(2), that applications are supposed to expect. These
 *     ones rely on the internal ones, and set errno.
 *
 * Each syscall will be defined with the two functions, sorted in alphabetical
 * order applied to the exported names.
 *
 * In case of doubt about the relevance of a function here, only those which
 * set errno should be defined here. Wrappers like those appearing in man(3)
 * should not be placed here.
 */


/*
 * int brk(void *addr);
 * void *sbrk(intptr_t inc)
 */

static __attribute__((unused))
void *_sys_brk(void *addr)
{
	return (void *)__nolibc_syscall1(__NR_brk, addr);
}

static __attribute__((unused))
int brk(void *addr)
{
	void *ret = _sys_brk(addr);

	if (!ret) {
		SET_ERRNO(ENOMEM);
		return -1;
	}
	return 0;
}

static __attribute__((unused))
void *sbrk(intptr_t inc)
{
	/* first call to find current end */
	void *ret = _sys_brk(NULL);

	if (ret && _sys_brk(ret + inc) == ret + inc)
		return ret + inc;

	SET_ERRNO(ENOMEM);
	return (void *)-1;
}


/*
 * int chdir(const char *path);
 * int fchdir(int fildes);
 */

static __attribute__((unused))
int _sys_chdir(const char *path)
{
	return __nolibc_syscall1(__NR_chdir, path);
}

static __attribute__((unused))
int chdir(const char *path)
{
	return __sysret(_sys_chdir(path));
}

static __attribute__((unused))
int _sys_fchdir(int fildes)
{
	return __nolibc_syscall1(__NR_fchdir, fildes);
}

static __attribute__((unused))
int fchdir(int fildes)
{
	return __sysret(_sys_fchdir(fildes));
}


/*
 * int chmod(const char *path, mode_t mode);
 */

static __attribute__((unused))
int _sys_chmod(const char *path, mode_t mode)
{
#if defined(__NR_fchmodat)
	return __nolibc_syscall4(__NR_fchmodat, AT_FDCWD, path, mode, 0);
#else
	return __nolibc_syscall2(__NR_chmod, path, mode);
#endif
}

static __attribute__((unused))
int chmod(const char *path, mode_t mode)
{
	return __sysret(_sys_chmod(path, mode));
}


/*
 * int chown(const char *path, uid_t owner, gid_t group);
 */

static __attribute__((unused))
int _sys_chown(const char *path, uid_t owner, gid_t group)
{
#if defined(__NR_fchownat)
	return __nolibc_syscall5(__NR_fchownat, AT_FDCWD, path, owner, group, 0);
#else
	return __nolibc_syscall3(__NR_chown, path, owner, group);
#endif
}

static __attribute__((unused))
int chown(const char *path, uid_t owner, gid_t group)
{
	return __sysret(_sys_chown(path, owner, group));
}


/*
 * int chroot(const char *path);
 */

static __attribute__((unused))
int _sys_chroot(const char *path)
{
	return __nolibc_syscall1(__NR_chroot, path);
}

static __attribute__((unused))
int chroot(const char *path)
{
	return __sysret(_sys_chroot(path));
}


/*
 * int close(int fd);
 */

static __attribute__((unused))
int _sys_close(int fd)
{
	return __nolibc_syscall1(__NR_close, fd);
}

static __attribute__((unused))
int close(int fd)
{
	return __sysret(_sys_close(fd));
}


/*
 * int dup(int fd);
 */

static __attribute__((unused))
int _sys_dup(int fd)
{
	return __nolibc_syscall1(__NR_dup, fd);
}

static __attribute__((unused))
int dup(int fd)
{
	return __sysret(_sys_dup(fd));
}


/*
 * int dup2(int old, int new);
 */

static __attribute__((unused))
int _sys_dup2(int old, int new)
{
#if defined(__NR_dup3)
	int ret, nr_fcntl;

#ifdef __NR_fcntl64
	nr_fcntl = __NR_fcntl64;
#else
	nr_fcntl = __NR_fcntl;
#endif

	if (old == new) {
		ret = __nolibc_syscall2(nr_fcntl, old, F_GETFD);
		return ret < 0 ? ret : old;
	}

	return __nolibc_syscall3(__NR_dup3, old, new, 0);
#else
	return __nolibc_syscall2(__NR_dup2, old, new);
#endif
}

static __attribute__((unused))
int dup2(int old, int new)
{
	return __sysret(_sys_dup2(old, new));
}


/*
 * int dup3(int old, int new, int flags);
 */

#if defined(__NR_dup3)
static __attribute__((unused))
int _sys_dup3(int old, int new, int flags)
{
	return __nolibc_syscall3(__NR_dup3, old, new, flags);
}

static __attribute__((unused))
int dup3(int old, int new, int flags)
{
	return __sysret(_sys_dup3(old, new, flags));
}
#endif


/*
 * int execve(const char *filename, char *const argv[], char *const envp[]);
 */

static __attribute__((unused))
int _sys_execve(const char *filename, char *const argv[], char *const envp[])
{
	return __nolibc_syscall3(__NR_execve, filename, argv, envp);
}

static __attribute__((unused))
int execve(const char *filename, char *const argv[], char *const envp[])
{
	return __sysret(_sys_execve(filename, argv, envp));
}


/*
 * void exit(int status);
 */

static __attribute__((noreturn,unused))
void _sys_exit(int status)
{
	__nolibc_syscall1(__NR_exit, status & 255);
	while(1); /* shut the "noreturn" warnings. */
}

static __attribute__((noreturn,unused))
void _exit(int status)
{
	_sys_exit(status);
}

static __attribute__((noreturn,unused))
void exit(int status)
{
	_exit(status);
}


/*
 * pid_t fork(void);
 */

#ifndef _sys_fork
static __attribute__((unused))
pid_t _sys_fork(void)
{
#if defined(__NR_clone)
	/* note: some archs only have clone() and not fork(). Different archs
	 * have a different API, but most archs have the flags on first arg and
	 * will not use the rest with no other flag.
	 */
	return __nolibc_syscall5(__NR_clone, SIGCHLD, 0, 0, 0, 0);
#else
	return __nolibc_syscall0(__NR_fork);
#endif
}
#endif

static __attribute__((unused))
pid_t fork(void)
{
	return __sysret(_sys_fork());
}

#ifndef _sys_vfork
static __attribute__((unused))
pid_t _sys_vfork(void)
{
#if defined(__NR_clone)
	/* See the note in _sys_fork(). */
	return __nolibc_syscall5(__NR_clone, CLONE_VM | CLONE_VFORK | SIGCHLD, 0, 0, 0, 0);
#elif defined(__NR_vfork)
	return __nolibc_syscall0(__NR_vfork);
#endif
}
#endif

static __attribute__((unused))
pid_t vfork(void)
{
	return __sysret(_sys_vfork());
}

/*
 * int fsync(int fd);
 */

static __attribute__((unused))
int _sys_fsync(int fd)
{
	return __nolibc_syscall1(__NR_fsync, fd);
}

static __attribute__((unused))
int fsync(int fd)
{
	return __sysret(_sys_fsync(fd));
}


/*
 * int getdents64(int fd, struct linux_dirent64 *dirp, int count);
 */

static __attribute__((unused))
int _sys_getdents64(int fd, struct linux_dirent64 *dirp, int count)
{
	return __nolibc_syscall3(__NR_getdents64, fd, dirp, count);
}

static __attribute__((unused))
int getdents64(int fd, struct linux_dirent64 *dirp, int count)
{
	return __sysret(_sys_getdents64(fd, dirp, count));
}


/*
 * uid_t geteuid(void);
 */

static __attribute__((unused))
uid_t _sys_geteuid(void)
{
#if defined(__NR_geteuid32)
	return __nolibc_syscall0(__NR_geteuid32);
#else
	return __nolibc_syscall0(__NR_geteuid);
#endif
}

static __attribute__((unused))
uid_t geteuid(void)
{
	return _sys_geteuid();
}


/*
 * pid_t getpgid(pid_t pid);
 */

static __attribute__((unused))
pid_t _sys_getpgid(pid_t pid)
{
	return __nolibc_syscall1(__NR_getpgid, pid);
}

static __attribute__((unused))
pid_t getpgid(pid_t pid)
{
	return __sysret(_sys_getpgid(pid));
}


/*
 * pid_t getpgrp(void);
 */

static __attribute__((unused))
pid_t _sys_getpgrp(void)
{
	return _sys_getpgid(0);
}

static __attribute__((unused))
pid_t getpgrp(void)
{
	return _sys_getpgrp();
}


/*
 * pid_t getpid(void);
 */

static __attribute__((unused))
pid_t _sys_getpid(void)
{
	return __nolibc_syscall0(__NR_getpid);
}

static __attribute__((unused))
pid_t getpid(void)
{
	return _sys_getpid();
}


/*
 * pid_t getppid(void);
 */

static __attribute__((unused))
pid_t _sys_getppid(void)
{
	return __nolibc_syscall0(__NR_getppid);
}

static __attribute__((unused))
pid_t getppid(void)
{
	return _sys_getppid();
}


/*
 * pid_t gettid(void);
 */

static __attribute__((unused))
pid_t _sys_gettid(void)
{
	return __nolibc_syscall0(__NR_gettid);
}

static __attribute__((unused))
pid_t gettid(void)
{
	return _sys_gettid();
}

#ifndef NOLIBC_NO_RUNTIME
static unsigned long getauxval(unsigned long key);

/*
 * int getpagesize(void);
 */

static __attribute__((unused))
int getpagesize(void)
{
	return __sysret((int)getauxval(AT_PAGESZ) ?: -ENOENT);
}
#endif /* NOLIBC_NO_RUNTIME */

/*
 * uid_t getuid(void);
 */

static __attribute__((unused))
uid_t _sys_getuid(void)
{
#if defined(__NR_getuid32)
	return __nolibc_syscall0(__NR_getuid32);
#else
	return __nolibc_syscall0(__NR_getuid);
#endif
}

static __attribute__((unused))
uid_t getuid(void)
{
	return _sys_getuid();
}


/*
 * int kill(pid_t pid, int signal);
 */

static __attribute__((unused))
int _sys_kill(pid_t pid, int signal)
{
	return __nolibc_syscall2(__NR_kill, pid, signal);
}

static __attribute__((unused))
int kill(pid_t pid, int signal)
{
	return __sysret(_sys_kill(pid, signal));
}


/*
 * int link(const char *old, const char *new);
 */

static __attribute__((unused))
int _sys_link(const char *old, const char *new)
{
#if defined(__NR_linkat)
	return __nolibc_syscall5(__NR_linkat, AT_FDCWD, old, AT_FDCWD, new, 0);
#else
	return __nolibc_syscall2(__NR_link, old, new);
#endif
}

static __attribute__((unused))
int link(const char *old, const char *new)
{
	return __sysret(_sys_link(old, new));
}


/*
 * off_t lseek(int fd, off_t offset, int whence);
 */

static __attribute__((unused))
off_t _sys_lseek(int fd, off_t offset, int whence)
{
#if defined(__NR_llseek)
	__kernel_loff_t loff = 0;
	off_t result;
	int ret;

	ret = __nolibc_syscall5(__NR_llseek, fd, offset >> 32, (uint32_t)offset, &loff, whence);
	if (ret < 0)
		result = ret;
	else
		result = loff;

	return result;
#else
	return __nolibc_syscall3(__NR_lseek, fd, offset, whence);
#endif
}

static __attribute__((unused))
off_t lseek(int fd, off_t offset, int whence)
{
	return __sysret(_sys_lseek(fd, offset, whence));
}


/*
 * int mkdir(const char *path, mode_t mode);
 */

static __attribute__((unused))
int _sys_mkdir(const char *path, mode_t mode)
{
#if defined(__NR_mkdirat)
	return __nolibc_syscall3(__NR_mkdirat, AT_FDCWD, path, mode);
#else
	return __nolibc_syscall2(__NR_mkdir, path, mode);
#endif
}

static __attribute__((unused))
int mkdir(const char *path, mode_t mode)
{
	return __sysret(_sys_mkdir(path, mode));
}

/*
 * int rmdir(const char *path);
 */

static __attribute__((unused))
int _sys_rmdir(const char *path)
{
#if defined(__NR_rmdir)
	return __nolibc_syscall1(__NR_rmdir, path);
#else
	return __nolibc_syscall3(__NR_unlinkat, AT_FDCWD, path, AT_REMOVEDIR);
#endif
}

static __attribute__((unused))
int rmdir(const char *path)
{
	return __sysret(_sys_rmdir(path));
}


/*
 * int mknod(const char *path, mode_t mode, dev_t dev);
 */

static __attribute__((unused))
long _sys_mknod(const char *path, mode_t mode, dev_t dev)
{
#if defined(__NR_mknodat)
	return __nolibc_syscall4(__NR_mknodat, AT_FDCWD, path, mode, dev);
#else
	return __nolibc_syscall3(__NR_mknod, path, mode, dev);
#endif
}

static __attribute__((unused))
int mknod(const char *path, mode_t mode, dev_t dev)
{
	return __sysret(_sys_mknod(path, mode, dev));
}


/*
 * int pipe2(int pipefd[2], int flags);
 * int pipe(int pipefd[2]);
 */

static __attribute__((unused))
int _sys_pipe2(int pipefd[2], int flags)
{
	return __nolibc_syscall2(__NR_pipe2, pipefd, flags);
}

static __attribute__((unused))
int pipe2(int pipefd[2], int flags)
{
	return __sysret(_sys_pipe2(pipefd, flags));
}

static __attribute__((unused))
int pipe(int pipefd[2])
{
	return pipe2(pipefd, 0);
}


/*
 * int pivot_root(const char *new, const char *old);
 */

static __attribute__((unused))
int _sys_pivot_root(const char *new, const char *old)
{
	return __nolibc_syscall2(__NR_pivot_root, new, old);
}

static __attribute__((unused))
int pivot_root(const char *new, const char *old)
{
	return __sysret(_sys_pivot_root(new, old));
}


/*
 * ssize_t read(int fd, void *buf, size_t count);
 */

static __attribute__((unused))
ssize_t _sys_read(int fd, void *buf, size_t count)
{
	return __nolibc_syscall3(__NR_read, fd, buf, count);
}

static __attribute__((unused))
ssize_t read(int fd, void *buf, size_t count)
{
	return __sysret(_sys_read(fd, buf, count));
}


/*
 * int sched_yield(void);
 */

static __attribute__((unused))
int _sys_sched_yield(void)
{
	return __nolibc_syscall0(__NR_sched_yield);
}

static __attribute__((unused))
int sched_yield(void)
{
	return __sysret(_sys_sched_yield());
}


/*
 * int setpgid(pid_t pid, pid_t pgid);
 */

static __attribute__((unused))
int _sys_setpgid(pid_t pid, pid_t pgid)
{
	return __nolibc_syscall2(__NR_setpgid, pid, pgid);
}

static __attribute__((unused))
int setpgid(pid_t pid, pid_t pgid)
{
	return __sysret(_sys_setpgid(pid, pgid));
}

/*
 * pid_t setpgrp(void)
 */

static __attribute__((unused))
pid_t setpgrp(void)
{
	return setpgid(0, 0);
}


/*
 * pid_t setsid(void);
 */

static __attribute__((unused))
pid_t _sys_setsid(void)
{
	return __nolibc_syscall0(__NR_setsid);
}

static __attribute__((unused))
pid_t setsid(void)
{
	return __sysret(_sys_setsid());
}


/*
 * int symlink(const char *old, const char *new);
 */

static __attribute__((unused))
int _sys_symlink(const char *old, const char *new)
{
#if defined(__NR_symlinkat)
	return __nolibc_syscall3(__NR_symlinkat, old, AT_FDCWD, new);
#else
	return __nolibc_syscall2(__NR_symlink, old, new);
#endif
}

static __attribute__((unused))
int symlink(const char *old, const char *new)
{
	return __sysret(_sys_symlink(old, new));
}


/*
 * mode_t umask(mode_t mode);
 */

static __attribute__((unused))
mode_t _sys_umask(mode_t mode)
{
	return __nolibc_syscall1(__NR_umask, mode);
}

static __attribute__((unused))
mode_t umask(mode_t mode)
{
	return _sys_umask(mode);
}


/*
 * int umount2(const char *path, int flags);
 */

static __attribute__((unused))
int _sys_umount2(const char *path, int flags)
{
	return __nolibc_syscall2(__NR_umount2, path, flags);
}

static __attribute__((unused))
int umount2(const char *path, int flags)
{
	return __sysret(_sys_umount2(path, flags));
}


/*
 * int unlink(const char *path);
 */

static __attribute__((unused))
int _sys_unlink(const char *path)
{
#if defined(__NR_unlinkat)
	return __nolibc_syscall3(__NR_unlinkat, AT_FDCWD, path, 0);
#else
	return __nolibc_syscall1(__NR_unlink, path);
#endif
}

static __attribute__((unused))
int unlink(const char *path)
{
	return __sysret(_sys_unlink(path));
}


/*
 * ssize_t write(int fd, const void *buf, size_t count);
 */

static __attribute__((unused))
ssize_t _sys_write(int fd, const void *buf, size_t count)
{
	return __nolibc_syscall3(__NR_write, fd, buf, count);
}

static __attribute__((unused))
ssize_t write(int fd, const void *buf, size_t count)
{
	return __sysret(_sys_write(fd, buf, count));
}


/*
 * int memfd_create(const char *name, unsigned int flags);
 */

static __attribute__((unused))
int _sys_memfd_create(const char *name, unsigned int flags)
{
	return __nolibc_syscall2(__NR_memfd_create, name, flags);
}

static __attribute__((unused))
int memfd_create(const char *name, unsigned int flags)
{
	return __sysret(_sys_memfd_create(name, flags));
}

#endif /* _NOLIBC_SYS_H */
